import json
import os
import signal
import subprocess
from .engine import Episode
from .policies import choose
from .common import canonical

def strict_json(text):
    def object_pairs(pairs):
        result={}
        for key,value in pairs:
            if key in result: raise ValueError('Duplicate JSON key')
            result[key]=value
        return result
    def constant(value): raise ValueError('Non-finite JSON number')
    return json.loads(text,object_pairs_hook=object_pairs,parse_constant=constant)

def adapter_call(argv,view,timeout=30):
    """Invoke a TRUSTED adapter, shell=False. Filesystem/network are not restricted."""
    if not isinstance(argv,list) or not argv or any(not isinstance(x,str) for x in argv):
        raise ValueError('Adapter command must be a nonempty JSON array of strings')
    if timeout<=0: raise ValueError('Timeout must be positive')
    proc=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          text=True,start_new_session=True)
    try:
        stdout,_=proc.communicate(canonical(view),timeout=timeout)
    except subprocess.TimeoutExpired:
        try: os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError: pass
        proc.communicate()
        raise TimeoutError('Adapter exceeded per-call timeout') from None
    if proc.returncode: raise RuntimeError(f'Adapter exited with code {proc.returncode}')
    if len(stdout.encode())>262144: raise ValueError('Adapter output exceeds protocol limit')
    return strict_json(stdout)

def run_episode(world_id,variant,seed=0,policy=None,adapter=None,timeout=30):
    if (policy is None)==(adapter is None): raise ValueError('Specify one policy or adapter')
    e=Episode(world_id,variant,seed)
    while not e.done:
        try: reply=choose(policy,e.view()) if policy else adapter_call(adapter,e.view(),timeout)
        except (OSError,ValueError,RuntimeError,TimeoutError) as exc:
            e.fail(type(exc).__name__,str(exc)); break
        e.step(reply)
    return e.artifact()
