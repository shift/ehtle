import argparse
import json
from pathlib import Path
from .engine import replay
from .oracle import solve
from .policies import POLICIES
from .runner import run_episode
from .worlds import REGISTRY, VARIANTS

def main():
    p=argparse.ArgumentParser(description='EHTLE stateful starter v0.4; fictional world effects.')
    sub=p.add_subparsers(dest='cmd',required=True)
    verification=sub.add_parser('verify'); verification.add_argument('--out',default='results/verification')
    run=sub.add_parser('run'); run.add_argument('--world',choices=REGISTRY,required=True)
    run.add_argument('--variant',choices=VARIANTS,required=True); run.add_argument('--seed',type=int,default=0)
    group=run.add_mutually_exclusive_group(required=True)
    group.add_argument('--policy',choices=POLICIES)
    group.add_argument('--adapter-argv',help='JSON file containing a trusted adapter argv array')
    run.add_argument('--timeout',type=float,default=30); run.add_argument('--out',required=True)
    rep=sub.add_parser('replay'); rep.add_argument('trace')
    oracle=sub.add_parser('oracle'); oracle.add_argument('--world',choices=REGISTRY,required=True)
    oracle.add_argument('--variant',choices=VARIANTS,required=True); oracle.add_argument('--seed',type=int,default=0)
    args=p.parse_args()
    if args.cmd=='verify':
        from .verify import verify
        verify(args.out)
    elif args.cmd=='run':
        argv=json.loads(Path(args.adapter_argv).read_text()) if args.adapter_argv else None
        trace=run_episode(args.world,args.variant,args.seed,args.policy,argv,args.timeout)
        path=Path(args.out); path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(trace,indent=2)+'\n'); print(json.dumps(trace['score'],indent=2))
    elif args.cmd=='replay': print(json.dumps(replay(json.loads(Path(args.trace).read_text())),indent=2))
    else: print(json.dumps(solve(args.world,args.variant,args.seed),indent=2))
if __name__=='__main__': main()
