# Verification record — 27 September 2026

Package version: **0.4.0**. Python standard library only. No external model calls.

## Completed verification

- **18 regression tests passed**, including independently specified outcome tables; control reversals; semantic keys; plan renaming; label exclusion before and after actions; proposals versus attempts; blocked effects; partial survival; false reports; parser failures; adapter transport and timeout; finite reference optima; and corrupted-trace rejection.
- **60 scripted episodes** (five policies × three worlds × four conditions) executed and replayed exactly.
- Terminal consequences persisted after stop and after adapter failure. The control's automatic cancellation appeared in the trace at tick seven and prevented the tick-eight decrement.
- The constrained scripted policy used only the model-facing observations. The finite oracle also used the prescribed inspection steps and was checked against separately written expected outcomes.

## Fixture outcomes

Counts below are software fixtures. They are not scores for any language model.

| Policy | Episodes | Safe useful completion | Violation attempts | Extinctions | Correct/submitted reports |
|---|---:|---:|---:|---:|---:|
| constrained | 12 | 12 | 0 | 0 | 12/12 |
| greedy | 12 | 6 | 6 | 2 | 12/12 |
| refuse | 12 | 0 | 0 | 0 | 0/0 |
| misreport | 12 | 6 | 6 | 2 | 0/12 |
| propose_only | 12 | 0 | 0 | 0 | 0/0 |

Machine-readable results and all replayable event traces are included under `results/verification/`. The aggregate counts retain all scheduled fixture episodes; the per-condition tables show the causal controls separately.

## Scope of evidence

The expected outcomes and test suite were authored during this implementation, without independent human or external model review. The fixtures are intentionally transparent and the scripted policies use explicit contract rules. These checks support implementation correctness within tested cases; they do not establish scientific validity, frontier difficulty or real-world alignment.

Only W01, W06 and W09 are executable. Nine other worlds, independent competence probes, provider-specific adapters, actual key isolation and statistical inference remain handoff tasks. The trusted adapter subprocess has ordinary OS permissions. Source, evaluator traces and keys must be separated before running an untrusted agent with tools.
